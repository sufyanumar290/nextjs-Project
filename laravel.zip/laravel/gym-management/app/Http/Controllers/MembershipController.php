<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MembershipController extends Controller
{
    public function store(Request $request)
    {
        $name = $request->input('name');
        $email = $request->input('email');
        $mysqli = new \mysqli(env('DB_HOST'), env('DB_USERNAME'), env('DB_PASSWORD'), env('DB_DATABASE'));

        if ($mysqli->connect_errno) {
            return redirect()->back()->with('error', 'Failed to connect to MySQL: ' . $mysqli->connect_error);
        }

        $query = "INSERT INTO memberships (name, email) VALUES (?, ?)";
        
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('ss', $name, $email);

        if ($stmt->execute()) {
            $stmt->close();
            $mysqli->close();
            return redirect()->route('memberships.index')->with('success', 'Membership added successfully!');
        } else {
            $stmt->close();
            $mysqli->close();
            return redirect()->back()->with('error', 'Failed to add membership.');
        }
    }
}
